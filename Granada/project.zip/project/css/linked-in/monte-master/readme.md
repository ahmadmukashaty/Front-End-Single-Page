## About Monte

A small carousel plugin for jQuery. See the [project page](http://jacklmoore.com/monte/) for documentation and a demonstration.  Released under the [MIT license](http://www.opensource.org/licenses/mit-license.php).
 
## Changelog:

### Version 1.0 - Oct. 18 2011
* First release